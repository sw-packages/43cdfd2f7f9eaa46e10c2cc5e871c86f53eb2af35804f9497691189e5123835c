#include <cstddef>
int main (int argc, char* argv[])
{
    std::size_t n = alignof(int);
    return 0;
}
